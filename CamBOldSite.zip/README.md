# Cbehdani.github.io

This is my personal website which contains side projects such as a Classroom Grade Calculator, a Pokedex, and more!